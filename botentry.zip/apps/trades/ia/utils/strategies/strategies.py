

class Strategy:
    def __init__(self, *args, **kwargs):
        pass    